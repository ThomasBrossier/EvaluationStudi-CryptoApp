module.exports = {
    plugins: {
        autoprefixer: {}
    }
}
