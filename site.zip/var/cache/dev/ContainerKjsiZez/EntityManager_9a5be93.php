<?php

namespace ContainerKjsiZez;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHoldera3096 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer80d0a = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesf9d8c = [
        
    ];

    public function getConnection()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getConnection', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getMetadataFactory', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getExpressionBuilder', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'beginTransaction', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getCache', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getCache();
    }

    public function transactional($func)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'transactional', array('func' => $func), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'wrapInTransaction', array('func' => $func), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'commit', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->commit();
    }

    public function rollback()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'rollback', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getClassMetadata', array('className' => $className), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'createQuery', array('dql' => $dql), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'createNamedQuery', array('name' => $name), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'createQueryBuilder', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'flush', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'clear', array('entityName' => $entityName), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->clear($entityName);
    }

    public function close()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'close', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->close();
    }

    public function persist($entity)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'persist', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'remove', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'refresh', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'detach', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'merge', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getRepository', array('entityName' => $entityName), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'contains', array('entity' => $entity), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getEventManager', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getConfiguration', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'isOpen', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getUnitOfWork', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getProxyFactory', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'initializeObject', array('obj' => $obj), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'getFilters', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'isFiltersStateClean', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'hasFilters', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return $this->valueHoldera3096->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer80d0a = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHoldera3096) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHoldera3096 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHoldera3096->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, '__get', ['name' => $name], $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        if (isset(self::$publicPropertiesf9d8c[$name])) {
            return $this->valueHoldera3096->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera3096;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldera3096;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera3096;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHoldera3096;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, '__isset', array('name' => $name), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera3096;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHoldera3096;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, '__unset', array('name' => $name), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldera3096;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHoldera3096;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, '__clone', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        $this->valueHoldera3096 = clone $this->valueHoldera3096;
    }

    public function __sleep()
    {
        $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, '__sleep', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;

        return array('valueHoldera3096');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer80d0a = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer80d0a;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer80d0a && ($this->initializer80d0a->__invoke($valueHoldera3096, $this, 'initializeProxy', array(), $this->initializer80d0a) || 1) && $this->valueHoldera3096 = $valueHoldera3096;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHoldera3096;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHoldera3096;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
